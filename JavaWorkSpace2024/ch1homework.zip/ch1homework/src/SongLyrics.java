// Brent Alexander 1-14-24 Ch1 Activity 1
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("You aint compared to us");
		System.out.println("You get bread, or what?");
		System.out.println("Worst off, yeah we wanna see you worst off");
		System.out.println("Are you Mad? Are you Glad?");

	}

}
