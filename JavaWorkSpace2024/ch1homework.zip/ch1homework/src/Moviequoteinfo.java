
public class Moviequoteinfo {
	
	public static void main(String[] args) {
		System.out.println("I do not fear the dark side as you do");
		System.out.println("I have Brought peace,freedom,justice and security to my new Empire?");
		System.out.println("Movie: Star Wars Revenge Of The Sith (2005)");
		System.out.println("Character: Anakin Skywalker");

	}

}
